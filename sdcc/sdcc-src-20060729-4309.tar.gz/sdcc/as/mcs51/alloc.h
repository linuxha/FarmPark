/* alloc.h */
/* DECUS C */

#include <stdlib.h>
