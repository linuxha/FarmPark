/* strcmpi.h */

int as_strcmpi (const char *s1, const char *s2);
