//dummy interrupt service routine
//just to make linker happy

void T2_isr (void) interrupt 5
{
}
