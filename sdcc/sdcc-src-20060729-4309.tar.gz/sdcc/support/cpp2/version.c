#include "ansidecl.h"
#include "version.h"

const char *const version_string = "3.1 20010625 (experimental) + SDCC";
