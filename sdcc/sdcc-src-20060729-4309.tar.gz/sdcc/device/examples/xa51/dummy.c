data char dummy_d1, dummy_d2=3;
xdata char dummy_x1, dummy_x2=3;
code char dummy_c1=4, dummy_c2=3;
bit dummy_b1;

// and some dummy code
int dummy(void) {
  return dummy_x2+dummy_c2;
}
