extern int ReadTemperature(int, uchar *, float *);
