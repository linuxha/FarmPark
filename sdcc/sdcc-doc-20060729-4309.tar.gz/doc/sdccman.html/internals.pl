# LaTeX2HTML 2002-2-1 (1.70)
# Associate internals original text with physical files.


$key = q/sub:ANSI-Compliance/;
$ref_files{$key} = "$dir".q|node172.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Loop-Optimizations/;
$ref_files{$key} = "$dir".q|node162.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Install-Trouble-shooting/;
$ref_files{$key} = "$dir".q|node28.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Peephole-Optimizer/;
$ref_files{$key} = "$dir".q|node171.html|; 
$noresave{$key} = "$nosave";

$key = q/cha:Debugging-with-SDCDB/;
$ref_files{$key} = "$dir".q|node131.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:Compatibility-with-previous/;
$ref_files{$key} = "$dir".q|node6.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:Parameters-and-Local-Variables/;
$ref_files{$key} = "$dir".q|node62.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Naked-Functions/;
$ref_files{$key} = "$dir".q|node80.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:External-Stack/;
$ref_files{$key} = "$dir".q|node94.html|; 
$noresave{$key} = "$nosave";

$key = q/type_promotion/;
$ref_files{$key} = "$dir".q|node139.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:A-Step-by_Assembler_Introduction/;
$ref_files{$key} = "$dir".q|node79.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:_switch_-Statements/;
$ref_files{$key} = "$dir".q|node165.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:Testing-the-SDCC/;
$ref_files{$key} = "$dir".q|node27.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:MCS51-variants/;
$ref_files{$key} = "$dir".q|node99.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:PIC16_Header-Files/;
$ref_files{$key} = "$dir".q|node120.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Overlaying/;
$ref_files{$key} = "$dir".q|node63.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:Related-open-source-tools/;
$ref_files{$key} = "$dir".q|node143.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Requesting-Features/;
$ref_files{$key} = "$dir".q|node148.html|; 
$noresave{$key} = "$nosave";

$key = q/OMF_file/;
$ref_files{$key} = "$dir".q|node41.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Windows-Install/;
$ref_files{$key} = "$dir".q|node23.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Interrupt-Service-Routines/;
$ref_files{$key} = "$dir".q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Intermediate-Dump-Options/;
$ref_files{$key} = "$dir".q|node54.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Install-paths/;
$ref_files{$key} = "$dir".q|node12.html|; 
$noresave{$key} = "$nosave";

$key = q/lyx:more-pedantic-SPLINT/;
$ref_files{$key} = "$dir".q|node53.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:PIC16_Pragmas/;
$ref_files{$key} = "$dir".q|node119.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Startup-Code/;
$ref_files{$key} = "$dir".q|node74.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Building-SDCC-on-Linux/;
$ref_files{$key} = "$dir".q|node15.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:The-anatomy-of/;
$ref_files{$key} = "$dir".q|node176.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Functions-using-private-banks/;
$ref_files{$key} = "$dir".q|node73.html|; 
$noresave{$key} = "$nosave";

$key = q/sub:Search-Paths/;
$ref_files{$key} = "$dir".q|node13.html|; 
$noresave{$key} = "$nosave";

1;

