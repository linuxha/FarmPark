# LaTeX2HTML 2002-2-1 (1.70)
# Associate images original text with physical files.


1;

